package com.barber.web.controller;
import com.barber.web.model.*; import com.barber.web.repo.*; import org.springframework.web.bind.annotation.*; import java.time.*; import java.util.*;
@RestController @RequestMapping("/api") @CrossOrigin(origins="*") public class Api {final ShopRepo shops;final BarberRepo barbers;final ServiceRepo services;final AppointmentRepo appointments; Api(ShopRepo s,BarberRepo b,ServiceRepo se,AppointmentRepo a){shops=s;barbers=b;services=se;appointments=a;}
@GetMapping("/shops") List<Shop> shops(){return shops.findByActiveTrue();}
@GetMapping("/shops/{id}") Shop shop(@PathVariable Long id){return shops.findById(id).orElseThrow();}
@GetMapping("/shops/{id}/barbers") List<Barber> barbers(@PathVariable Long id){return barbers.findByShopIdAndActiveTrue(id);}
@GetMapping("/shops/{id}/services") List<ServiceItem> services(@PathVariable Long id){return services.findByShopIdAndActiveTrue(id);}
@GetMapping("/shops/{id}/appointments") List<Appointment> appts(@PathVariable Long id,@RequestParam String date){return appointments.findByShopIdAndDateOrderByTimeAsc(id,LocalDate.parse(date));}
@PostMapping("/appointments") Appointment create(@RequestBody Appointment a){if(appointments.existsByShopIdAndBarberIdAndDateAndTimeAndStatusNot(a.getShopId(),a.getBarberId(),a.getDate(),a.getTime(),"CANCELLED")) throw new IllegalStateException("That time is already booked");return appointments.save(a);}
}
