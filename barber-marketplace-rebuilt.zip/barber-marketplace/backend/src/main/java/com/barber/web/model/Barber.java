package com.barber.web.model;
import jakarta.persistence.*;
@Entity public class Barber { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) Long id; String name,imageUrl; Long shopId; boolean active=true; public Barber(){} public Barber(String n,String i,Long s){name=n;imageUrl=i;shopId=s;} public Long getId(){return id;} public String getName(){return name;} public String getImageUrl(){return imageUrl;} public Long getShopId(){return shopId;} public boolean isActive(){return active;} }
