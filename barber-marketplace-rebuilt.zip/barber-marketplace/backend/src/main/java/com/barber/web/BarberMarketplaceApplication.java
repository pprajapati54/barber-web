package com.barber.web;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication public class BarberMarketplaceApplication { public static void main(String[] args){SpringApplication.run(BarberMarketplaceApplication.class,args);} }
