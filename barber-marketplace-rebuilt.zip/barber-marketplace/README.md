# Barber Marketplace — Web First

Customer flow: search barber shop → select shop → choose service → choose barber → choose date/time → confirm booking.

Barber marketplace data model supports multiple shops, each with barbers and services.

## Run without Docker
Terminal 1:
```bash
cd backend
./mvnw spring-boot:run
```
Terminal 2:
```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0
```
Open Codespaces port 5173. H2 is used for zero-setup development; MySQL can be added later for production.
