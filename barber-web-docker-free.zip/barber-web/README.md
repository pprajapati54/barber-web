# Barber Web — Docker-Free MVP

Web-first barber management system: barber dashboard + mobile customer booking.

## Run in GitHub Codespaces

Backend:
```bash
cd backend
chmod +x mvnw
./mvnw spring-boot:run
```

Frontend (new terminal):
```bash
cd frontend
npm install
npm run dev -- --host 0.0.0.0
```

Open forwarded port 5173. Admin is `/admin`; customer booking is `/`.

The default database is file-based H2, so no Docker or MySQL is required for development.

For production, switch to the MySQL profile using DB_URL, DB_USERNAME and DB_PASSWORD.
