package com.barber.web.model;
import jakarta.persistence.*;
@Entity public class Customer { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) Long id; String name; String phone; String email; public Customer(){} public Customer(String n,String p,String e){name=n;phone=p;email=e;} public Long getId(){return id;} public String getName(){return name;} public String getPhone(){return phone;} public String getEmail(){return email;} }
