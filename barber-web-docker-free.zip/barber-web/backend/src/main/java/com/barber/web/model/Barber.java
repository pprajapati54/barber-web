package com.barber.web.model;
import jakarta.persistence.*;
@Entity public class Barber { @Id @GeneratedValue(strategy=GenerationType.IDENTITY) Long id; String name; boolean active=true; public Barber(){} public Barber(String n){name=n;} public Long getId(){return id;} public String getName(){return name;} public boolean isActive(){return active;} }
