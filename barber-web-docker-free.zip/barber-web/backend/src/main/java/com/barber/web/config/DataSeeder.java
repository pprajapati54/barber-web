package com.barber.web.config;
import com.barber.web.model.*; import com.barber.web.repo.*; import org.springframework.boot.CommandLineRunner; import org.springframework.context.annotation.*;
@Configuration public class DataSeeder { @Bean CommandLineRunner seed(BarberRepository b,ServiceItemRepository s){return a->{if(b.count()==0){b.save(new Barber("Raj"));b.save(new Barber("Amit"));}if(s.count()==0){s.save(new ServiceItem("Haircut",30,150));s.save(new ServiceItem("Haircut + Beard",45,250));s.save(new ServiceItem("Beard Trim",20,100));s.save(new ServiceItem("Hair Spa",45,400));}};} }
