package com.barber.web.controller;
import com.barber.web.model.*; import com.barber.web.repo.*; import org.springframework.web.bind.annotation.*; import java.time.*; import java.util.*;
@RestController @RequestMapping("/api") @CrossOrigin(origins="*") public class ApiController { final ServiceItemRepository s; final BarberRepository b; final AppointmentRepository a; final CustomerRepository c; public ApiController(ServiceItemRepository s,BarberRepository b,AppointmentRepository a,CustomerRepository c){this.s=s;this.b=b;this.a=a;this.c=c;}
@GetMapping("/services") List<ServiceItem> services(){return s.findByActiveTrue();} @GetMapping("/barbers") List<Barber> barbers(){return b.findByActiveTrue();}
@GetMapping("/appointments") List<Appointment> appointments(@RequestParam(required=false)String date){return a.findByDateOrderByTimeAsc(date==null?LocalDate.now():LocalDate.parse(date));}
@PostMapping("/appointments") Appointment create(@RequestBody Appointment x){return a.save(x);} @PatchMapping("/appointments/{id}/status") Appointment status(@PathVariable Long id,@RequestParam String value){var x=a.findById(id).orElseThrow();x.setStatus(value);return a.save(x);}
@GetMapping("/customers") List<Customer> customers(){return c.findAll();}
}
