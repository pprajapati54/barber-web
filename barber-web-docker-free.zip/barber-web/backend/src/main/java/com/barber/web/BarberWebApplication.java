package com.barber.web;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class BarberWebApplication { public static void main(String[] args){SpringApplication.run(BarberWebApplication.class,args);} }
