package com.barber.web.model;
import jakarta.persistence.*;
@Entity public class ServiceItem {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) Long id; String name; int durationMinutes; double price; boolean active=true;
 public ServiceItem(){} public ServiceItem(String n,int d,double p){name=n;durationMinutes=d;price=p;}
 public Long getId(){return id;} public String getName(){return name;} public void setName(String v){name=v;} public int getDurationMinutes(){return durationMinutes;} public double getPrice(){return price;} public boolean isActive(){return active;}
}
